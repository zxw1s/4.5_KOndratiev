<script>
    import ComputerImg from '../../lib/images/computer1-front.jpg';
    import ComputerImg1 from '../../lib/images/computer1-back.jpg';

</script>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    text-align: center;
}

h1 {
    color: rgb(59, 2, 2);
}



.flip-card {
    background-color: transparent;
    width: 200px;
    height: 200px;
    perspective: 1000px;
}

.flip-card-inner {
    position: relative;
    width: 100%;
    height: 100%;
    text-align: center;
    transition: transform 0.6s;
    transform-style: preserve-3d;
}

.flip-card:hover .flip-card-inner {
    transform: rotateY(180deg);
}

.flip-card-front, .flip-card-back {
    position: absolute;
    width: 100%;
    height: 100%;
    backface-visibility: hidden;
}

.flip-card-front {
    background-color: #bbb;
    color: black;
}

.flip-card-back {
    background-color: #555;
    color: white;
    transform: rotateY(180deg);
}
</style>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Компьютер 1</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
</head>
<body>
    <h1>Компьютер 1</h1>
    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="{ComputerImg}" width="300" alt="Computer 1 Front">
            </div>
            <div class="flip-card-back">
                <h6> Один из самых мощных игровых компьютеров GIGABYTE Aorus 
                    продается с восьмиядерным процессором Intel Core i9-11900K 
                    с частотой 3 500 МГц. Тип оперативной памяти у данной модели – DDR4
                     с объемом 16 ГБ (две планки) и частотой 3 200 МГц.
                      Также у ПК емкий накопитель SSD на 3 ГБ.
                       Для расширения памяти предусмотрены разъем M.2 для SSD-накопителя
                        и четыре входа U-DIMM для модулей ОЗУ DDR4, два из которых уже заняты.</h6>
            </div>
        </div>
    </div>
    <h1>Компьютер 2</h1>
    <div class="flip-card">
        <div class="flip-card-inner">
            <div class="flip-card-front">
                <img src="{ComputerImg1}" width="300" alt="Computer 1 Front">
            </div>
            <div class="flip-card-back">
                <h6> Для игр отлично подходит настольный ПК ALIENWARE AURORA R10 RYZEN EDITION
                     на базе восьмиядерного процессора Intel Core i9-11900F. 
                     Объем оперативной памяти типа DDR4 содержит 32 ГБ.
                      Видеокарта установлена дискретная NVIDIA GeForce RTX 3090 
                      с объемом видеопамяти 24 ГБ и частотой 32 ГГц. </h6>
            </div>
        </div>
</body>
</html>
