<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Разнообразие компьютеров</title>
    <link rel="stylesheet" href="styles.css">
    <script src="script.js" defer></script>
</head>
<body style="background-image: url('background.jpg');">
    <h1>Список компьютеров</h1>
    <ul>
        <li><a href="computer1.svelte">Компьютер 1</a></li>
        <li><a href="computer2.svelte">Компьютер 2</a></li>
        <!-- Добавьте другие компьютеры по аналогии -->
    </ul>
</body>
</html>

