import * as universal from "../../../../src/routes/computer1/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/computer1/+page.svelte";